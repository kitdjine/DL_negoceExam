# dlnegoce-exam
dlnegoce-exam

Run Spring Boot Application and follow instructions from index.html page

good dev ;)