$(document).ready(function() {
	ajaxGetCatalog(layoutCatalog);
	ajaxComputeAndDisplayStatistic();
	$("#catalogBlock").hide();
	$("#hideCatalogButtonId").hide();
	$("#showCatalogButtonId").click(function(event) {
		event.preventDefault();
		$("#catalogBlock").show();
		$("#showCatalogButtonId").hide();
		$("#hideCatalogButtonId").show();
		ajaxGetCatalog(displayCatalogAction);
	});

	$("#hideCatalogButtonId").click(function(event) {
		event.preventDefault();
		$("#showCatalogButtonId").show();
		$("#hideCatalogButtonId").hide();
		$("#catalogBlock").hide();

	});

})

//get asked statistic 
function ajaxComputeAndDisplayStatistic() {
	$
			.ajax({
				type : "GET",
				url : window.location + "catalog-stats",
				success : function(result) {
					if (result) {
						$('#statisticBlock ul').empty();
						var numberOfNode = "Nombre total de noeuds : "+ result.catalogQty;
						$('#numberOfNodes').append( numberOfNode );
						$.each(result.levelStatistic, function(i,levelStatistic) {
							var stat = "Quantity du niveau "+ levelStatistic.level + " : "+ levelStatistic.qty;
							$('#statisticBlock ul').append(
									"<li>" + stat + "</li>")
						});
					} else {
						displayError("Il y a eu une erreur pendant le calcul des statistiques");
						console.log("Fail: ", result);
						return null;
					}
				},
				error : function(e) {
					displayError("Il y a eu une erreur pendant le calcul des statistiques");
					console.log("ERROR: ", e);
					return null;
				}
			});
}

//get the catalog object
function ajaxGetCatalog(callback) {
	$.ajax({
		type : "GET",
		url : window.location + "catalog",
		success : function(result) {
			if (result) {
				callback(result);
			} else {
				displayError("Il y a eu une erreur pour charger le cataloque");
				console.log("Fail: ", result);
			}
		},
		error : function(e) {
			displayError("Il y a eu une erreur pour charger le cataloque");
			console.log("ERROR: ", e);
		}
	});
}

function displayCatalogAction(data) {
	displayPrettyJson(data, "catalogJSon");
}
function layoutCatalog(data) {
	displayPrettyJson(data, "catalog");
}

function displayPrettyJson(data, inputAreaId) {
	var pretty = JSON.stringify(data, undefined, 4);
	document.getElementById(inputAreaId).value = pretty;
}

function displayError(errorMessage) {
	alert(errorMessage);
}