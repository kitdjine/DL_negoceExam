package com.dlnegoce.exam.model;

import java.util.List;

public class CatalogStatistic {
	private int catalogQty = 0;
	private int base = 0;
	List<LevelStatistic> levelStatistic;
	
	public int getCatalogQty() {
		return catalogQty;
	}
	public void setCatalogQty(int catalogueMainQty) {
		this.catalogQty = catalogueMainQty;
	}
	public int getBase() {
		return base;
	}
	public void setBase(int base) {
		this.base = base;
	}
	public List<LevelStatistic> getLevelStatistic() {
		return levelStatistic;
	}
	public void setLevelStatistic(List<LevelStatistic> levelStatistic) {
		this.levelStatistic = levelStatistic;
	}
	
}

