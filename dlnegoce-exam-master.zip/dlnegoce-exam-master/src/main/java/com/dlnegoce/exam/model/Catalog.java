package com.dlnegoce.exam.model;

import java.util.List;


public class Catalog {
	private String name;
	private List<Children> children;
	
	public List<Children> getChildren() {
		return children;
	}
	public void setChildren(List<Children> children) {
		this.children = children;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
