package com.dlnegoce.exam.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dlnegoce.exam.model.Catalog;
import com.dlnegoce.exam.model.CatalogStatistic;
import com.dlnegoce.exam.model.Children;
import com.dlnegoce.exam.model.LevelStatistic;
import com.dlnegoce.exam.tools.Utilities;


@RestController
public class ExamController {
	private final static String CATALOG_JSON_FILE = "catalog.json";
	/**
	 * 
	 * @return 
	 */
	// TODO : load catalog.json file to the appropriate java object and return it
    @RequestMapping("/catalog")
    public Catalog catalog() {
    	Catalog catalog = null;
    	try {
    		catalog =  Utilities.mapJsonClassPathFileToObject(CATALOG_JSON_FILE,Catalog.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
        return catalog;
    }

    // TODO : calculate the following statistics of the catalog :
    // - total number of nodes
    // - count level 1 and 2 based on level 3 and show results
    // TODO : And return statistics results with the appropriate object
    @RequestMapping("/catalog-stats")
    public CatalogStatistic catalogStat() {
    	int base = 3;
    	CatalogStatistic catalogStatistic = null;
    	try {
	    	Catalog catalog = Utilities.mapJsonClassPathFileToObject(CATALOG_JSON_FILE,Catalog.class);
	    	int nodeQty = calculateNodes(catalog.getChildren());
	    	catalogStatistic = new CatalogStatistic();
	    	List<LevelStatistic> levelStatistics = new ArrayList<LevelStatistic>();
	    	if(catalog != null && catalog.getChildren()!=null) {
		    	catalogStatistic.setBase(base);
		    	catalogStatistic.setCatalogQty(nodeQty);
		    	Children childrenOfGivenBase = catalog.getChildren().get(base-1);
		    	if(childrenOfGivenBase.hasChildren()) {
		    		for (int i = 0; i < 2; i++) {
		    			Children currentChildren = childrenOfGivenBase.getChildren().get(i);
			    		LevelStatistic levelStatistic = new LevelStatistic();
			    		levelStatistic.setLevel(i+1);
			    		if(currentChildren.hasChildren()) {
			    			levelStatistic.setQty(calculateNodes(childrenOfGivenBase.getChildren().get(i).getChildren()));
				    		levelStatistics.add(levelStatistic);
			    		}
					}
		    	}
		    	
	    	}
	    	catalogStatistic.setLevelStatistic(levelStatistics);
	    	
    	} catch (IOException e) {
			e.printStackTrace();
		}
        return catalogStatistic;
    }

	private int calculateNodes(List<Children> calatlogChildren) {
		int size = calatlogChildren.size();
		for (Children children : calatlogChildren) {
			if(children.hasChildren()) {
				int newSize = getSize(children);
				size = size + newSize;
			}
		}
		return size;
	}

	private int getSize(Children children) {
		int size = 0;
		if(children.hasChildren()) {
			size =  children.getChildren().size();
			for (Children c : children.getChildren()) {
				int result = size + getSize(c);
				size = result;
			}
		}
		return size;
	}
}

