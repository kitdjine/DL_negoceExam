package com.dlnegoce.exam.model;

import java.util.List;

import org.springframework.util.CollectionUtils;




public class Children {
	private String code;
	private String path;
	private String name;
	private String count;
	List<Children> children;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public List<Children> getChildren() {
		return children;
	}
	public void setChildren(List<Children> children) {
		this.children = children;
	}
	
	public boolean hasChildren() {
		if(!CollectionUtils.isEmpty(this.children)) {
			return true;
		}else {
			return false;
		}
	}
	
}
