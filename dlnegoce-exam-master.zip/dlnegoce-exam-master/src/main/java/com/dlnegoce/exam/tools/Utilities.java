package com.dlnegoce.exam.tools;

import java.io.File;
import java.io.IOException;

import org.springframework.core.io.ClassPathResource;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public final class Utilities {
	
	/**
	 * get files under resource repository.
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	public static File getClassPathFile(String fileName) throws IOException {
		File file = new ClassPathResource(fileName).getFile();
		return file;
	}
	
	/**
	 * return the java object corresponding to a JSON file.
	 * @param <T>
	 * @param string
	 * @param mappingClass
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public static <T> T mapJsonClassPathFileToObject(String filename, Class<T> mappingClass) throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.readValue(Utilities.getClassPathFile(filename), mappingClass);
	}

}
